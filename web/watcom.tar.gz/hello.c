#include <stdio.h>

int main(void)
{
	int i, s = 0;
	for (i = 1; i <= 10; i++)
		s += i;
	printf("hello from Watcom C, sum=%d\n", s);
	return 0;
}
