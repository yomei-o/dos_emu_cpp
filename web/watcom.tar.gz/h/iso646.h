/*
 *  iso646.h	Normative Addendum alternative spellings
 *
 *  Copyright by WATCOM International Corp. 1988-1996.  All rights reserved.
 *  Copyright by Sybase, Inc. 1997-1999.  All rights reserved.
 */
#ifndef _ISO646_H_INCLUDED
#define _ISO646_H_INCLUDED
#if !defined(_ENABLE_AUTODEPEND)
  #pragma read_only_file;
#endif


#define and	&&
#define and_eq	&=
#define bitand	&
#define bitor	|
#define compl	~
#define ne	!=
#define not	!
#define or	||
#define or_eq	|=
#define xor	^
#define xor_eq	^=


#endif
