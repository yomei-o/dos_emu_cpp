//
//  eh.h	Cover file to include except.h
//
//  Copyright by WATCOM International Corp. 1988-1996.  All rights reserved.
//  Copyright by Sybase, Inc. 1997-1999.  All rights reserved.
//
#ifndef _EH_H_INCLUDED
#define _EH_H_INCLUDED
#if !defined(_ENABLE_AUTODEPEND)
  #pragma read_only_file;
#endif

#ifndef __cplusplus
#error eh.h is for use with C++
#endif

#ifndef _EXCEPT_H_INCLUDED
 #include <except.h>
#endif

#endif
