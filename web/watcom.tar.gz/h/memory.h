/*
 *  memory.h	Memory manipulation functions
 *
 *  Copyright by WATCOM International Corp. 1988-1996.  All rights reserved.
 *  Copyright by Sybase, Inc. 1997-1999.  All rights reserved.
 */
#ifndef _MEMORY_H_INCLUDED
#define _MEMORY_H_INCLUDED
#if !defined(_ENABLE_AUTODEPEND)
  #pragma read_only_file;
#endif

#ifndef _STRING_H_INCLUDED
 #include <string.h>
#endif

#endif
