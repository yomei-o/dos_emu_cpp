#include <stdio.h>

struct Greeter {
	const char* who;
	Greeter(const char* w) : who(w) {}
	virtual ~Greeter() {}
	virtual void hello(int n) const { printf("hello from %s, sum=%d\n", who, n); }
};

struct Loud : Greeter {
	Loud(const char* w) : Greeter(w) {}
	void hello(int n) const { printf("HELLO FROM %s, SUM=%d\n", who, n); }
};

static int triangle(int n)
{
	int s = 0;
	for (int i = 1; i <= n; ++i) s += i;
	return s;
}

int main()
{
	Greeter a("Watcom C++");
	Loud b("Watcom C++");
	const Greeter* v[2] = { &a, &b };
	for (int i = 0; i < 2; i++) v[i]->hello(triangle(10));
	return 0;
}
